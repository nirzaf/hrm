<?php
// module directory name
$HmvcConfig['nodb']["_title"]     = "nodb Management System";
$HmvcConfig['nodb']["_description"] = "Simple nodb System";


// register your module tables
// only register tables are imported while installing the module
$HmvcConfig['nodb']['_database'] = false;
$HmvcConfig['nodb']["_tables"] = array( 
	
);
