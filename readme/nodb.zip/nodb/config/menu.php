<?php

// module name
$HmvcMenu["nodb"] = array(
    //set icon
    "icon"           => "<i class='fa fa-users'></i>", 
    
    //menu name
    "email" => array( 
        "controller" => "single",
        "method"     => "index",
        "permission" => "create"
    ),  
);
   

 