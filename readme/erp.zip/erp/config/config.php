<?php
// module directory name
$HmvcConfig['erp']["_title"]     = "Erp Management System";
$HmvcConfig['erp']["_description"] = "Simple Erp System";


// register your module tables
// only register tables are imported while installing the module
$HmvcConfig['erp']['_database'] = false;
$HmvcConfig['erp']["_tables"] = array( 
	'erp_vehicle_information',
	'erp_vehicle_type',  
);
