
CREATE TABLE `erp_vehicle_information` (
  `v_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `v_model_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `v_registration_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `v_chassis_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `v_engine_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `v_type` varchar(255) CHARACTER SET latin1 NOT NULL,
  `posting_id` int(10) NOT NULL,
  `active` int(2) NOT NULL,
  `v_owner` int(11) NOT NULL,
  PRIMARY KEY (`v_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `erp_vehicle_type` (
  `v_type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `v_type` varchar(255) CHARACTER SET latin1 NOT NULL,
  `posting_id` varchar(255) CHARACTER SET latin1 NOT NULL,
  `active` int(2) NOT NULL,
  PRIMARY KEY (`v_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


