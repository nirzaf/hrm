<?php
// module directory name
$HmvcConfig['inventory']["_title"]       = "Inventory Management System";
$HmvcConfig['inventory']["_description"] = "Simple Inventory System";


// register your module tables
// only register tables are imported while installing the module
$HmvcConfig['inventory']['_database'] = false;
$HmvcConfig['inventory']["_tables"] = array( 
	'tbl_category',
	'tbl_invoice',  
	'tbl_supplier',  
);
